---
name: cdp-agent
description: "Build, extend, and deploy the CDP AI Agent — a SaaS-embeddable AI operations assistant for customer data platforms. Covers architecture, tool patterns, deployment, and UI preferences."
version: 1.0.0
---

# CDP AI Agent — SaaS 智能运营助手

完整项目路径：`/Users/xu/AgentProject/agent-for-saas/`

## 架构

```
app/
├── main.py          # FastAPI v3.0 (42 endpoints)
├── agent.py         # ReAct engine (37 tools, DeepSeek function calling)
├── auth.py          # API Key auth + RBAC (admin/analyst/viewer)
├── models.py        # Multi-model management (DeepSeek/Qwen/GLM)
├── database.py      # DataSource abstraction (Mock/SQLite/MySQL)
├── scheduler.py     # asyncio task scheduler
├── rag.py           # TF-IDF knowledge base search
├── webhook.py       # Webhook callback system
├── store.py         # SQLite session persistence
├── errors.py        # LLM retry with exponential backoff
├── structured.py    # ToolResult + SQL/JSON output models
└── tools/           # 37 AI tools across 15 files
```

## ToolResult Pattern

All tools MUST return `ToolResult(text=..., structured={...})`. The agent extracts `.text` for the LLM and `.structured` for the API response.

```python
from app.structured import ToolResult

def my_tool(param: str) -> str:
    return ToolResult(
        text="Human readable result",
        structured={"type": "my_tool", "data": {...}},
    )
```

Return type annotation is `str` (not `ToolResult`) because the agent codebase uses `str` annotations for tool functions.

## Agent Tool Registration

1. Create tool in `app/tools/cdp_xxx.py`
2. Add to `app/tools/__init__.py`
3. Add tool definition dict to `TOOL_DEFINITIONS` in `agent.py`
4. Add import and `tool_map` entry to `_execute_tool` in `agent.py`

## UI Preferences

- **Theme**: Light warm orange (`#f08050` accent, `#faf8f5` bg)
- **Markdown**: Compact — `\n\n+` → `<br>`, single `\n` → remove
- **Action buttons**: Tool-driven (match by `tools[]` array), NOT text-matching
- **Edit box**: 200px minimum height
- **Chinese IME**: `!e.isComposing` guard on Enter key
- **Identity**: "CDP 小助手", never mention Claude/Anthropic

## RBAC

```python
permissions = {
    "admin": {"chat", "analyze", "manage", "export", "read"},
    "analyst": {"chat", "analyze", "export", "read"},
    "viewer": {"read"},
}
```

API Key creation via POST body (NOT query params):
```bash
curl -X POST /admin/keys -d '{"role":"viewer","name":"readonly"}'
```

## Deployment

Service managed by LaunchAgent at `~/Library/LaunchAgents/com.cdp.agent.plist`.
External access via frp: localhost:8800 → 8.163.113.208:8080.
Admin panel: `http://8.163.113.208:8080/admin`
Demo chat: `http://8.163.113.208:8080/demo`
JS SDK: `http://8.163.113.208:8080/static/chat-widget.js`

## Pitfalls

- **FastAPI role parameter**: POST JSON body fields are NOT automatically bound to function params. Use `request: Request` + `await request.json()` for POST data.
- **Module-level `__file__`**: Use `resolve()` when paths break in LaunchAgent context.
- **frp proxy conflicts**: Kill all frpc, wait 90s for frps heartbeat timeout, then restart with unique proxy names.
- **ChromaDB model download**: ChromaDB downloads ONNX models (~80MB) from S3. Use TF-IDF instead for small document sets to avoid slow downloads in China.
- **Regex code replacement**: Never use regex for bulk code changes in Python files. Use string.replace() with exact matches or write_file() for clean rewrites.
- **LaunchAgent chicken-egg**: Don't put `require_role` on `/admin/keys` — first key creation needs no auth.
