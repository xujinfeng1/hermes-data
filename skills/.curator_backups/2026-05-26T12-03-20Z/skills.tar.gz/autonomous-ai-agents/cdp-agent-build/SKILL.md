---
name: cdp-agent-build
description: Build a CDP SaaS-ready AI Agent — architecture, tool patterns, structured output, RBAC, multi-model
version: 1.0.0
metadata:
  hermes:
    tags: [cdp, agent, saas, fastapi, tools, structured-output, rbac]
---

# CDP Agent Building

## Architecture

```
app/
├── main.py          # FastAPI (42 endpoints)
├── agent.py         # ReAct engine (37 tools, DeepSeek function calling)
├── auth.py          # API Key auth + RBAC (admin/analyst/viewer)
├── database.py      # DataSource abstraction (mock/SQLite/MySQL)
├── models.py        # Multi-model manager (cost tracking + fallback)
├── scheduler.py     # asyncio task scheduler (daily/weekly/interval)
├── store.py         # SQLite session persistence
├── rag.py           # TF-IDF knowledge base
├── errors.py        # Exponential backoff retry
├── structured.py    # ToolResult + SQL/JSON builders
└── tools/           # One tool file per domain
```

## Tool Pattern

Every tool returns `ToolResult(text, structured)`:
- `text` → goes to LLM context (human readable)
- `structured` → goes to API consumer (machine readable: SQL, JSON filter, workflow JSON)

```python
from app.structured import ToolResult, SegmentOutput

def segment_users(gender=None, ...):
    return ToolResult(
        text="找到 5 人...",
        structured=SegmentOutput(conditions=[...], sql_where="gender='女'", user_count=5).__dict__,
    )
```

Agent extracts: `text` for LLM, `structured` for API response.

## RBAC Pitfall

FastAPI function params like `role: str = "admin"` read from **query string**, not POST body.
When receiving JSON body `{"role": "viewer"}`, it silently defaults to `"admin"`.
Fix: read from `await request.json()`.

```python
# WRONG
async def create_key(role: str = "admin"):
# RIGHT  
async def create_key(request: Request):
    body = await request.json()
    role = body.get("role", "admin")
```

## frp + LaunchAgent Conflict

If frpc is managed by a LaunchAgent with `KeepAlive=true`, killing the process triggers immediate restart.
The new instance conflicts with old proxy registrations on frps ("already exists" error).
Fix: `launchctl unload` first, update config, wait >90s for frps heartbeat timeout, `launchctl load`.

## Chinese IME

Bind `keydown` with `e.isComposing` check to avoid Enter sending during IME composition:
```js
function onKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { send(); }
}
```

## Model Switching

Models defined in `models.py` as `ModelProvider` dataclasses.
Agent dynamically reads `model_mgr.get_current()` for base_url/model/api_key each turn.
Cost tracked per model via `model_mgr.record_usage()`.

## Demo UI Patterns

- Confirmation dialogs for destructive actions (canvas execute, segment create)
- Inline edit → save → re-render for agent output modification
- Markdown table → HTML table rendering
- Structured data cards (SQL snippet, workflow preview)
