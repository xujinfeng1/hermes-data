---
name: agent-product-dev
description: "Build sellable AI Agent products with FastAPI + LLM function calling. Architecture patterns for multi-tool agents, structured output, RBAC, multi-tenant SaaS."
version: 1.0.0
metadata:
  hermes:
    tags: [agent, saas, product, fastapi, architecture]
    category: autonomous-ai-agents
---

# Agent Product Development

Build production-grade AI Agent products that can be sold to SaaS companies.

## Architecture Pattern

```
app/
├── main.py          FastAPI (endpoints + middleware)
├── agent.py         ReAct loop + tool definitions
├── models.py        Multi-model management
├── auth.py          API Key + RBAC
├── database.py      Data source abstraction (mock → MySQL)
├── scheduler.py     Task scheduler
├── store.py         SQLite persistent sessions
├── rag.py           Knowledge base retrieval
├── structured.py    ToolResult + structured output models
├── errors.py        Error types + LLM retry with backoff
└── tools/           AI tools (one file per domain)
```

## Key Design Decisions

### ToolResult pattern
Every tool returns `ToolResult(text=..., structured=...)`. The `text` goes to the LLM context, the `structured` dict is extracted by the API and returned alongside the NL reply. This is the bridge between "agent says something" and "SaaS consumes structured data".

### Data source abstraction
Never hardcode JSON file reads in tools. Use a `DataSource` ABC with `query_users()`, `query_events()`, etc. Switch between Mock (JSON files) and SQL (MySQL/SQLite) transparently.

### Multi-model with fallback
Define models as dataclasses with `base_url`, `model`, `api_key_env`, `cost_per_1k_*`. The agent reads from the model manager on each call. Add `try_fallback()` to auto-switch on failure.

### RBAC
Three roles minimum: admin (full), analyst (chat+analyze), viewer (read-only). Store role on the API key. Check permissions in dependencies, not in endpoint bodies — use `require_role("chat")` as a FastAPI dependency.

### Structured output for SaaS integration
- Segment → SQL WHERE + JSON filter
- Canvas → Workflow JSON with node configs (channel, template, params)
- Analytics → Funnel steps + counts + rates

## Pitfalls

- **FastAPI query params on POST** — `role: str="admin"` in a POST endpoint reads from query string, not JSON body. Use `await request.json()` for POST data.
- **API Key bootstrap** — admin key creation endpoint must be open (no auth) or you have a chicken-and-egg problem.
- **LaunchAgent cwd** — set `WorkingDirectory` in the plist explicitly, or relative file paths break.
- **frp proxy conflicts** — when killing/restarting frpc, old sessions linger on frps for ~90s. Wait for heartbeat timeout or use unique proxy names.

## Reference

See `references/cdp-agent-reference.md` for the full CDP Agent implementation — 42 tools, 46 APIs, architecture patterns, UI code snippets.
