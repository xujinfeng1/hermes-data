---
name: cdp-agent-product
description: "Build and deploy a CDP AI Agent product for SaaS — architecture, tools, deployment, and demo."
version: 1.0.0
metadata:
  hermes:
    tags: [cdp, agent, saas, product, demo, deployment]
---

# CDP AI Agent Product

Build a CDP (Customer Data Platform) AI Agent that can be embedded into SaaS
systems. The agent enables marketing operators to use natural language for:
audience segmentation (圈人), user profiling, marketing canvas creation,
funnel/retention/campaign analytics, churn prediction, and autonomous
campaign execution.

## Architecture

```
FastAPI app (app/main.py)
  ├── app/agent.py          # ReAct loop + tool definitions
  ├── app/auth.py           # API keys, tenants, quota
  ├── app/store.py          # SQLite session persistence
  ├── app/errors.py         # LLM retry with exponential backoff
  ├── app/structured.py     # ToolResult, SQL/JSON filter builder
  ├── app/rag.py            # TF-IDF knowledge base search
  └── app/tools/
      ├── cdp_audience.py   # segment_users, list_segments
      ├── cdp_profile.py    # get_user_profile, get_user_events
      ├── cdp_tag.py        # create_marketing_canvas (7 goals)
      ├── cdp_analytics.py  # funnel, retention, campaign analysis
      ├── cdp_predict.py    # churn, LTV, NBA, anomaly detection
      ├── cdp_auto.py       # health check, auto campaign, optimize
      └── cdp_rag.py        # search_knowledge_base
```

## Project Setup

```bash
cd /path/to/project
python3.11 -m venv venv
source venv/bin/activate
pip install fastapi uvicorn httpx python-dotenv pydantic chromadb
```

Set `DEEPSEEK_API_KEY` in `.env`. See `.env.example` in the project root.

## Tool Design Pattern

All tools return `ToolResult(text=str, structured=dict|None)`. The `text` field
feeds into the LLM context. The `structured` field is consumed by the
`/chat/structured` endpoint and returned to the SaaS for programmatic use.

**Structured output types** (defined in `app/structured.py`):
- `SegmentOutput` — SQL WHERE clause + JSON filter + user list
- `CanvasOutput` — Workflow JSON with trigger/message/branch/ab_test/eval nodes
- `FunnelOutput` / `RetentionOutput` / `CampaignOutput` — Metrics arrays

**SQL builder**: `build_sql_where(conditions, operator)` converts condition dicts
to SQL. `build_json_filter()` converts to MongoDB-style queries.

## RAG Knowledge Base

Uses TF-IDF (not embeddings) for small doc sets (<1000 docs). Why:
- ChromaDB's DefaultEmbeddingFunction downloads 80MB ONNX model from AWS S3,
  which is extremely slow in China (~20KB/s)
- TF-IDF requires zero downloads, works instantly, and is sufficient for
  10-100 document knowledge bases
- For production: switch to ChromaDB + Chinese embedding model (text2vec, bge)
  once the model is pre-cached

Documents live in `data/knowledge_base.json`. Auto-ingested on server startup
via the FastAPI lifespan handler.

## Deployment (External Access)

### Option A: frp tunnel (Easiest, no SSH to server needed)
1. Ensure frps is running on the VPS
2. Add proxy to `~/.hermes/frpc.toml`:
   ```toml
   [[proxies]]
   name = "cdp-demo"
   type = "tcp"
   localIP = "127.0.0.1"
   localPort = 8800
   remotePort = 8080
   ```
3. Restart frpc (unload/reload LaunchAgent if Hermes manages it)

### Option B: Direct deploy to ECS
SSH into ECS, copy project, pip install, run with systemd supervisor.

### LaunchAgent (macOS persistence)
```xml
<!-- ~/Library/LaunchAgents/com.cdp.agent.plist -->
<key>ProgramArguments</key>
<array>
    <string>/path/to/venv/bin/python</string>
    <string>-m</string><string>uvicorn</string>
    <string>app.main:app</string>
    <string>--host</string><string>0.0.0.0</string>
    <string>--port</string><string>8800</string>
</array>
<key>WorkingDirectory</key><string>/path/to/project</string>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><true/>
```

## API Endpoints

| Endpoint | Auth | Purpose |
|----------|------|---------|
| `POST /chat` | Bearer | NL conversation |
| `POST /chat/structured` | Bearer | NL + structured (SQL/JSON/WF) |
| `POST /chat/stream` | Bearer | SSE streaming |
| `GET /health` | None | Liveness check |
| `GET /health/detailed` | Bearer | Tenant info + quota |
| `GET /demo` | None | Web chat UI |
| `POST /admin/keys` | None | Create API key |
| `GET /admin/usage` | None | Token usage stats |
| `POST /ingest` | Bearer | Upload knowledge docs |
| `GET /kb/stats` | Bearer | KB stats |

## Demo Web UI

Single-file HTML at `demo.html`. Served at `/demo`. Features:
- API key input + endpoint selector (local/remote)
- Quick-action buttons for common CDP tasks
- Auto-display of structured output (SQL, workflow JSON) below responses
- Works standalone (open `demo.html` directly) or via the server

## Key Design Decisions

- **TF-IDF over ChromaDB embeddings**: Faster startup, no model download. Punt
  on vector search until doc count exceeds ~200.
- **ToolResult dual-output**: Every tool returns human text for LLM context AND
  machine-readable structured data for API consumers. This is the bridge
  between conversational AI and SaaS integration.
- **Single-model for now**: DeepSeek only. Multi-model switching adds complexity
  without adding selling points at this stage.
- **Mock data in JSON files**: Phase 1-8 use mock JSON. Real database
  integration (MySQL/ClickHouse) is the next major milestone.
