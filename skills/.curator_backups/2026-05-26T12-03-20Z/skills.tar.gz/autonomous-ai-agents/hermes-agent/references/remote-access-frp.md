# frp Self-Hosted Tunnel for Hermes Dashboard

Full recipe for exposing `hermes dashboard` to the internet via frp
(fast reverse proxy). Requires a VPS with public IP (e.g., Alibaba Cloud ECS).

## Architecture

```
Phone/Internet → http://VPS_IP:8080 → [frps on VPS] → [frpc on Mac] → localhost:9119
```

## Step 1: VPS (Server Side — frps)

Pick the cheapest ECS (e.g., Alibaba Cloud, 2-core/512MB ~¥24/mo), Ubuntu 22.04.

```bash
# SSH into VPS
ssh root@<VPS_IP>

# Download latest frp (check https://github.com/fatedier/frp/releases)
curl -fsSL -o /tmp/frp.tar.gz \
  "https://github.com/fatedier/frp/releases/download/v0.68.1/frp_0.68.1_linux_amd64.tar.gz"
cd /tmp && tar xzf frp.tar.gz
cp frp_0.68.1_linux_amd64/frps /usr/local/bin/
mkdir -p /etc/frp
```

**frps config** (`/etc/frp/frps.toml`):
```toml
bindPort = 7000

webServer.addr = "0.0.0.0"
webServer.port = 7500
webServer.user = "admin"
webServer.password = "hermes2026"
```

**systemd service** (`/etc/systemd/system/frps.service`):
```ini
[Unit]
Description=frp server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/frps -c /etc/frp/frps.toml
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload && systemctl enable --now frps
```

### Open firewall ports (Alibaba Cloud security group)

Go to ECS console → Security Group → Inbound Rules → Add:

| Port | Purpose |
|------|---------|
| 7000 | frp control (frpc ↔ frps) |
| 7500 | frp admin dashboard |
| 8080 | Hermes WebUI (the forwarded port) |

All: TCP, Source `0.0.0.0/0`.

## Step 2: Local Machine (Client Side — frpc)

```bash
# Download frp for macOS ARM64
curl -fsSL -o /tmp/frp.tar.gz \
  "https://github.com/fatedier/frp/releases/download/v0.68.1/frp_0.68.1_darwin_arm64.tar.gz"
cd /tmp && tar xzf frp.tar.gz
cp frp_0.68.1_darwin_arm64/frpc ~/.local/bin/
chmod +x ~/.local/bin/frpc
```

**frpc config** (`~/.hermes/frpc.toml`):
```toml
serverAddr = "<VPS_IP>"
serverPort = 7000

[[proxies]]
name = "hermes-webui"
type = "tcp"
localIP = "127.0.0.1"
localPort = 9119
remotePort = 8080
```

**launchd auto-start** (`~/Library/LaunchAgents/com.hermes.frpc.plist`):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.hermes.frpc</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/<USER>/.local/bin/frpc</string>
        <string>-c</string>
        <string>/Users/<USER>/.hermes/frpc.toml</string>
    </array>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>StandardOutPath</key>
    <string>/Users/<USER>/.hermes/logs/frpc.log</string>
    <key>StandardErrorPath</key>
    <string>/Users/<USER>/.hermes/logs/frpc.log</string>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.hermes.frpc.plist
```

## Step 3: Dashboard CORS

The dashboard's CORS middleware only allows `localhost` by default.
When accessed through frp, the browser origin is `http://<VPS_IP>:8080`.

**Fix:** Patch `hermes_cli/web_server.py` → `start_server()`. When `host not in _LOCALHOST`
(i.e., `--insecure`), set `allow_origin_regex` to `r"https?://.*"` — a broad
allowlist. The `--insecure` flag is a deliberate operator choice so a broad
CORS policy is appropriate.

```bash
hermes dashboard --host 0.0.0.0 --insecure --tui --no-open
```

Verify:
```bash
curl -sv -X OPTIONS \
  -H "Origin: http://<VPS_IP>:8080" \
  -H "Access-Control-Request-Method: GET" \
  http://<VPS_IP>:8080/api/status 2>&1 | grep access-control-allow-origin
# Expected: access-control-allow-origin: http://<VPS_IP>:8080
```

## Step 4: Access

From any device: `http://<VPS_IP>:8080`

## Troubleshooting

**frpc exits with "dial tcp ... i/o timeout":** Security group isn't allowing port 7000.
Check Alibaba Cloud console.

**HTTP 200 but blank page / broken Chat tab:** CORS isn't configured. Check
`access-control-allow-origin` header with the curl test above.

**frps TOML format warning:** Old INI-style config uses `bind_port` (underscore).
New TOML format uses `bindPort` (camelCase). v0.68+ prefers TOML.

## GitHub Download Notes (China)

If GitHub downloads timeout, use `ghproxy.net`:
```bash
curl -fsSL -o frp.tar.gz \
  "https://ghproxy.net/https://github.com/fatedier/frp/releases/download/v0.68.1/frp_0.68.1_linux_amd64.tar.gz"
```
