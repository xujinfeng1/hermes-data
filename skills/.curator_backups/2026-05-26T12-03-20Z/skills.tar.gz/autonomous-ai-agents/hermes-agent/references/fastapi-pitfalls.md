# FastAPI 常见坑

## POST body 参数不会被自动注入到函数参数

```python
# ❌ 错误：role 从 query string 读取，POST body 里的 role 被忽略
@app.post("/admin/keys")
async def create_key(role: str = "admin"):
    ...

# ✅ 正确：从 request.json() 读取 body
@app.post("/admin/keys")
async def create_key(request: Request):
    body = await request.json()
    role = body.get("role", "admin")
    ...
```

**症状：** 用 `curl -d '{"role":"viewer"}'` 发送，但后端始终收到默认值 "admin"。

**原因：** FastAPI 的 `param: type = default` 默认从 query string 读取。POST body 里的字段需要显式 `await request.json()` 解析。

## Depends 依赖注入链路

```python
# 定义鉴权依赖
async def get_auth(request: Request):
    ...  # 返回 dict，如 {"tenant": ..., "role": "admin"}

# 定义权限检查依赖（嵌套 Depends）
def require_role(action: str):
    async def checker(auth=Depends(get_auth)):
        if not check_permission(auth["role"], action):
            raise HTTPException(403, ...)
        return auth
    return checker

# 使用
@app.post("/chat")
async def chat(auth=Depends(require_role("chat"))):
    ...
```

FastAPI 自动解析嵌套的 `Depends` 链路。

## 返回值类型变更需要全局更新

当 `validate_api_key` 返回类型从 `Tenant` 变成 `dict{"tenant": Tenant, "role": str}` 时，所有使用 `tenant: object = Depends(get_current_tenant)` 的端点都需要更新：

```python
# 旧
async def chat(tenant: object = Depends(get_current_tenant)):
    t = tenant  # 直接是 Tenant 对象

# 新
async def chat(auth: object = Depends(get_current_tenant)):
    t = auth["tenant"]  # 从 dict 中提取
```

## Admin 端点自举问题

如果 admin 端点需要鉴权才能访问，但初始状态没有任何 key，会形成死锁。
解决：首次启动时 `/admin/keys` 不需要鉴权，或者启动时自动创建 bootstrap key。
