# 通过 skills CLI 安装外部技能集

第三方 CLI 工具 `skills`（npm 包）可以从 GitHub 仓库批量安装技能到 Hermes 及其他 Agent。

## 安装方式

```bash
# 交互式选择安装（按空格勾选，回车确认）
npx skills@latest add mattpocock/skills

# 非交互式全装（加 -y）
npx skills@latest add mattpocock/skills -y
```

## 安装位置

技能同时安装到两处：
- `~/.hermes/skills/` — Hermes 直接加载
- `~/.agents/skills/` — 通用库（symlink 到 Hermes）

## 常见技能集

| 仓库 | 说明 |
|------|------|
| `mattpocock/skills` | Matt Pocock 的工程技能集（diagnose、tdd、grill-me 等 14 个） |

## 注意事项

- 如果 GitHub 直连超时（国内环境），先确保代理可用，或用 ghproxy 加速 clone
- 安装后技能立即可用，无需重启 Hermes（`/reload-skills` 刷新）
- 安装器会做安全扫描，注意查看风险提示
