# China Mirror Reference

When GitHub is slow or blocked from mainland China, use these mirrors.

## Node.js

Download prebuilt binaries from npmmirror:

```bash
# Check latest version
curl -fsSL https://npmmirror.com/mirrors/node/latest-v22.x/SHASUMS256.txt | grep darwin-arm64

# Download (macOS arm64)
curl -fsSL -o /tmp/node.tar.gz \
  "https://npmmirror.com/mirrors/node/latest-v22.x/node-v22.20.0-darwin-arm64.tar.gz"
tar xzf /tmp/node.tar.gz
mv node-v22.20.0-darwin-arm64 ~/.local/node
ln -sf ~/.local/node/bin/node ~/.local/bin/node
ln -sf ~/.local/node/bin/npm ~/.local/bin/npm
```

## GitHub Releases (generic)

### 步骤 1：探路 —— 用 API 找到准确的资产名

GitHub Releases 的资产命名没有统一规范（可能是 `.tar.gz`、`.tgz`、或裸二进制），先通过 API 查：

```bash
curl -sL -H "Accept: application/vnd.github+json" \
  -H "User-Agent: curl/8.0" \
  --connect-timeout 15 \
  "https://api.github.com/repos/<org>/<repo>/releases/latest" \
  | python3 -c "
import sys, json
data = json.load(sys.stdin)
print('Version:', data.get('tag_name'))
for a in data.get('assets', []):
    print(f\"  {a['name']}  ({a['size']} bytes)\")
"
```

根据输出来定位你需要的平台/架构资产名（如 `deepseek-tui-macos-arm64`）。

### 步骤 2：下载 —— ghproxy 前缀 + curl 断点续传

大文件（>20MB）走 ghproxy 仍然可能超时。务必加 `-C -` 断点续传：

```bash
# 格式
curl -L -C - --connect-timeout 15 -o <output> \
  "https://ghproxy.net/https://github.com/<org>/<repo>/releases/download/<tag>/<asset>"

# 实例：下载 DeepSeek TUI (37MB)
curl -L -C - --connect-timeout 15 -o deepseek-tui \
  "https://ghproxy.net/https://github.com/Hmbown/DeepSeek-TUI/releases/download/v0.8.39/deepseek-tui-macos-arm64"

chmod +x <output>
```

`-C -` 会自动从上次中断的位置继续，重复执行即可。超时后再次运行不会重头开始。

### 步骤 3：验证

```bash
file <output>        # 确认是 Mach-O / ELF / PE 等正确格式
<output> --version   # 确认能运行
```

### 裸二进制（非 tar 包）

某些项目（如 DeepSeek TUI）发布的是裸二进制而非 tar 包。下载到 `~/.local/bin/` 后直接 `chmod +x` 即可：

```bash
cd ~/.local/bin
curl -L -C - --connect-timeout 15 -o <name> \
  "https://ghproxy.net/https://github.com/<org>/<repo>/releases/download/<tag>/<asset>"
chmod +x <name>
```

### 多二进制项目

部分项目需要同时下载多个二进制（如 DeepSeek TUI 需要 `deepseek` + `deepseek-tui`）。通过步骤 1 的 API 查询找出所有需要的资产，逐个下载到同一目录。

## npm

npm itself usually works fine via the default registry. If not, set mirror:

```bash
npm config set registry https://registry.npmmirror.com
```
