# Dashboard CORS Fix for LAN/Mobile Access

## Problem

The Hermes dashboard CORS middleware (`hermes_cli/web_server.py`) hardcodes
`allow_origin_regex` to only match `localhost` and `127.0.0.1`. When accessing
from a mobile device at `http://192.168.x.x:9119`, the browser's `Origin` header
is rejected by CORS:

- The HTML/JS loads (static file serving bypasses CORS)
- API calls fail silently (REST endpoints return no `access-control-allow-origin`)
- WebSocket connections fail (Chat tab PTY bridge never connects)
- Symptom: Chat tab appears but keyboard input doesn't work

## Fix: Two-Part Patch to `web_server.py`

### Part 1: Extract CORS regex to a module-level variable (line ~102)

Before:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_methods=["*"],
    allow_headers=["*"],
)
```

After:
```python
_CORS_ALLOW_ORIGIN_REGEX = r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$"

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=_CORS_ALLOW_ORIGIN_REGEX,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Part 2: Expand CORS in `start_server()` when `--insecure` is active (after `app.state.bound_port = port`)

Insert after the `app.state.bound_port = port` line in `start_server()`:

```python
    # When binding to all-interfaces (--insecure), expand CORS to accept
    # any origin.  This is required for reverse-proxy / tunnel setups where
    # the browser Origin differs from the bound host.  The operator already
    # accepted the risk by passing --insecure.
    if host not in _LOCALHOST:
        _CORS_ALLOW_ORIGIN_REGEX = r"https?://.*"
        for mw in app.user_middleware:
            if mw.cls.__name__ == "CORSMiddleware":
                mw.kwargs["allow_origin_regex"] = _CORS_ALLOW_ORIGIN_REGEX
                break
```

This broad regex is appropriate because `--insecure` is an explicit operator choice
accepting the security trade-off. It handles all remote-access scenarios: LAN IP,
frp tunnel, Cloudflare Tunnel, Tailscale, etc. — without needing to detect specific
IPs at startup.

## Verification

After patching and restarting the dashboard:

```bash
# Should return 200 with access-control-allow-origin header:
curl -sv -X OPTIONS \
  -H "Origin: http://192.168.0.116:9119" \
  -H "Access-Control-Request-Method: GET" \
  http://192.168.0.116:9119/api/status 2>&1 | grep access-control-allow-origin
# Expected: access-control-allow-origin: http://192.168.0.116:9119
```

## Notes

- The Host header middleware (`_is_accepted_host`) already handles `0.0.0.0`
  binds correctly — no change needed there (line 196-197).
- The `_ws_client_is_allowed()` function already handles `--insecure` mode
  — no change needed there (line 3169-3170).
- Only the CORS middleware needed patching.
- The broad `https?://.*` regex works on all platforms (macOS, Linux, Windows).
