---
name: ai-agent-development
description: "Build production AI agents with FastAPI: ReAct loop, tool system, structured output, RAG, and SaaS integration patterns."
version: 1.0.0
metadata:
  hermes:
    tags: [ai-agent, fastapi, tool-system, structured-output, rag, saas]
---

# AI Agent Development Patterns

Proven patterns for building production-grade AI agents with FastAPI, tested on the CDP Agent project (19 tools, 24 endpoints, 8 phases).

## Core Architecture

```
app/
├── agent.py           # ReAct loop + tool definitions + system prompt
├── main.py            # FastAPI endpoints + auth middleware
├── config.py           # Env-based configuration
├── schemas.py          # Pydantic request/response models
├── auth.py             # API key auth + multi-tenant + quota
├── store.py            # Persistent session storage (SQLite)
├── errors.py           # Error types + LLM retry with backoff
├── structured.py       # ToolResult model + SQL/JSON builders
├── rag.py              # Knowledge base engine
└── tools/
    ├── __init__.py     # Tool registry (imports all tools)
    ├── cdp_audience.py # Domain-specific tool
    ├── cdp_predict.py  # Another domain tool
    └── ...
```

## Tool System Pattern

Every tool returns `ToolResult(text, structured)`:

```python
from app.structured import ToolResult

def my_tool(param: str) -> str:  # Return type str for LLM compatibility
    return ToolResult(
        text="Human-readable result for the LLM",
        structured={"type": "my_tool", "data": {...}}  # Machine-readable for API
    )
```

**Registration flow**:
1. Create tool in `app/tools/my_tool.py`
2. Import in `app/tools/__init__.py`
3. Add function definition to `TOOL_DEFINITIONS` in `agent.py`
4. Add to `_execute_tool` import and `tool_map`

**Agent _execute_tool** unpacks ToolResult:
```python
result = fn(**args)
if isinstance(result, ToolResult):
    return result.text, result.structured  # text → LLM, structured → API
```

## Structured Output

Key pattern: SaaS integration requires machine-readable output alongside NL replies.

- `/chat` returns `ChatResponse(reply, session_id, tool_calls_made, structured)`
- `/chat/structured` adds top-level `sql` and `json_filter` fields
- Structure types: `segment` (SQL where clause), `canvas` (workflow JSON), `funnel` (metrics)

## RAG Without Model Downloads

In China/restricted networks, embedding model downloads can be extremely slow.
Use TF-IDF as a zero-dependency retrieval engine for knowledge bases under 1000 documents:

```python
class TfidfSearcher:
    def index(self, documents): ...
    def search(self, query, top_k=3) -> list[dict]: ...
```

Replaces ChromaDB + embedding model. Supports Chinese via character n-gram tokenization.
Later upgrade to vector search when model download is feasible.

## Agent Identity

System prompt MUST explicitly define identity and prohibit mentioning third-party AI vendors:

```
你是 CDP 小助手，一个专为客户数据平台打造的 AI 运营助手。
- 永远不要提及 Claude、GPT、OpenAI、Anthropic 等第三方 AI 公司
- 如果用户问你是谁，回答产品的自我介绍
```

## FastAPI Patterns

- **Auth**: Depends-based `get_current_tenant` with Bearer token
- **Quota**: Check before processing, record after, release in finally
- **Session persistence**: SQLite with WAL mode, auto-save after each turn
- **Cron jobs**: Use `cronjob` tool for scheduled reports (daily/weekly)

## Pitfalls

- **Tool return types**: Tools return `str` for LLM function calling compatibility, but internally they're `ToolResult`. The `_execute_tool` function unpacks them.
- **Streaming**: `run_agent_stream` needs separate implementation; don't try to wrap `run_agent` for streaming.
- **Import errors on restart**: If `main.py` imports a function from `agent.py` that was removed, the server won't start. Always keep `run_agent_stream` even if you don't use it, or remove the import from `main.py`.
- **State isolation**: Each `execute_code` and `uvicorn` process has its own Python process. Creating a key via Python script doesn't register it in the running server process. Always use the REST API to mutate server state.
