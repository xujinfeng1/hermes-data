---
name: cdp-agent-saas
description: "Build a CDP (Customer Data Platform) AI Agent product for SaaS — architecture, tools, deployment, and competitive landscape."
version: 1.0.0
author: Hermes Agent
platforms: [linux, macos]
metadata:
  hermes:
    tags: [cdp, agent, saas, ai-agent, customer-data-platform, marketing-automation, product-development]
---

# CDP AI Agent for SaaS

Build an embeddable AI Agent product for CDP SaaS companies. The agent replaces
traditional CDP operations (drag-and-drop segment builder, SQL queries, canvas
designer) with natural language conversation.

## Product Positioning

**Not a CDP. A "CDP AI Co-pilot"** — any CDP SaaS integrates it and instantly
gives their customers conversational operation capability.

Core value proposition:
- To SaaS companies: "Add AI conversation to your CDP, lower user barrier, increase stickiness"
- To end users: "Stop learning CDP operations. Just speak Chinese."

## Architecture

```
SaaS Frontend → Agent API (FastAPI) → Agent Core (ReAct + Function Calling)
                                          ├── Audience Tools (NL segmentation)
                                          ├── Profile Tools (360° user view)
                                          ├── Canvas Tools (marketing journey)
                                          └── Analytics Tools (funnel/retention/campaign)
```

## Phase Roadmap

### Phase 1: Core Engine
- FastAPI + DeepSeek/OpenAI function calling
- ReAct loop with tool execution
- Mock data for all CDP domains

### Phase 2: CDP Tools
- Audience segmentation (NL → conditions → user set)
- User 360° profile + behavior timeline
- Tag management (list/search/define)
- Marketing canvas (7 goal types: 促首单/促复购/挽回流失/提升客单价/大促预热/弃购挽回/生日营销)

### Phase 3: Analytics Engine
- Funnel analysis (NL → step conversion rates)
- Retention analysis (Day 1/3/7/14/30 cohorts)
- Campaign performance dashboard

### Phase 4: Standard Agent Features
- API Key auth (Bearer token)
- Multi-tenant isolation (tenant_id scoping)
- Quota & rate limiting (token/month, requests/min, concurrency)
- Persistent session store (SQLite)
- Structured logging & health monitoring
- LLM retry with exponential backoff

## Competitive Landscape

All major CDPs (神策, GrowingIO, Segment, mParticle, Treasure Data, BlueConic)
have **NO conversational AI agent**. The only exception is Salesforce Agentforce,
which is locked into Salesforce ecosystem, priced at $2/conv, and unavailable in China.

This is a genuine market gap.

See `references/competitive-landscape.md` for the full competitive matrix
with 14 products analyzed across both global and Chinese markets.

## Key Technical Patterns

### NL → Tool Call Flow

```
User: "圈出近30天买过3次以上的女性VIP"
     ↓
LLM: segment_users(gender="女", level="VIP", min_orders_30d=3)
     ↓
Tool: filter mock data → return matching users
     ↓
LLM: format response with table + suggestions
```

### System Prompt Design

The system prompt must include:
1. Role definition (CDP operations assistant)
2. Core capabilities with trigger examples
3. Condition mapping table (NL phrases → parameter values)
4. Workflow rules (e.g., "when creating canvas, first verify audience exists")
5. Language and tone constraints

### Tool Function Signatures

Use type hints + detailed docstrings. The LLM uses parameter descriptions
to correctly map NL conditions to function args:

```python
def segment_users(
    gender: Optional[str] = None,  # 性别: 男/女
    min_orders_30d: Optional[int] = None,  # 近30天最少购买次数
    ...
) -> str:
```

## Pitfalls

- **Mock data must be rich enough**: 10+ users with realistic stats, 30+ events
  with timestamps, 10+ tags, 5+ pre-built segments. Sparse data makes the agent
  look broken when it returns empty results.
- **System prompt is everything**: Without the condition mapping table, the LLM
  won't correctly translate "高消费" → min_total_spent=10000.
- **Stream + tool calls**: When streaming, tool call chunks arrive fragmented.
  Accumulate them in a buffer before executing.
- **Session context**: Multi-turn conversations need session persistence. Without
  it, follow-up questions like "刚才那个人的画像" fail.
- **DeepSeek API**: Uses standard OpenAI-compatible function calling format.
  Tools are defined as `[{"type": "function", "function": {...}}]`.
