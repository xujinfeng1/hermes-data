---
name: cdp-agent-development
description: "Build CDP AI Agents for SaaS products — architecture, tool patterns, structured output, RAG, predictions."
version: 1.0.0
author: Hermes Agent
platforms: [linux, macos]
metadata:
  hermes:
    tags: [cdp, agent, saas, architecture, tools, rag, predictions]
---

# CDP Agent for SaaS — Development Guide

Build a sellable CDP AI Agent product that embeds into existing SaaS platforms.
Architecture: FastAPI + DeepSeek + ReAct loop + structured output.

## Project Structure

```
agent-for-saas/
├── app/
│   ├── agent.py          # Core ReAct loop + tool definitions
│   ├── main.py           # FastAPI (chat, admin, webhook, reports)
│   ├── auth.py           # API Key auth + multi-tenant + quotas
│   ├── store.py          # SQLite session persistence + usage logs
│   ├── errors.py         # Retry logic (exponential backoff)
│   ├── schemas.py        # Pydantic request/response models
│   ├── config.py         # Env-based config
│   ├── structured.py     # ToolResult + SQL/JSON builders
│   ├── rag.py            # TF-IDF search engine (no model download)
│   ├── webhook.py        # Webhook registration + fire
│   └── tools/
│       ├── cdp_audience.py   # Segment users → SQL WHERE clause
│       ├── cdp_profile.py    # User 360° view + event timeline
│       ├── cdp_tag.py        # Tag management + 7 canvas templates
│       ├── cdp_analytics.py   # Funnel/retention/campaign analysis
│       ├── cdp_rag.py         # Knowledge base search tool
│       ├── cdp_predict.py     # Churn/LTV/NBA/anomaly detection
│       ├── cdp_auto.py        # Health check/auto-execute/optimize
│       ├── cdp_report.py      # Daily/weekly reports
│       └── cdp_advanced.py    # Attribution + cohort analysis
├── data/                  # Mock data + knowledge base
├── demo.html              # Self-contained chat UI
└── venv/
```

## Core Pattern: ToolResult

Every tool returns `ToolResult(text=str, structured=dict|None)`.
- `text` goes to the LLM for conversation
- `structured` goes to the API response for SaaS consumption

```python
from app.structured import ToolResult, SegmentOutput, build_sql_where

def segment_users(gender="女", min_total_spent=10000):
    # ... filter users ...
    conditions = [
        {"field": "gender", "op": "eq", "value": "女"},
        {"field": "total_spent", "op": "gte", "value": 10000},
    ]
    return ToolResult(
        text="找到 5 人：张三、李四...",
        structured=SegmentOutput(
            conditions=conditions,
            sql_where=build_sql_where(conditions),  # "gender = '女' AND total_spent >= 10000"
            user_count=5,
        ).__dict__,
    )
```

## Agent Tool Registration

In `agent.py`, each tool needs:
1. A function definition in `TOOL_DEFINITIONS` (OpenAI-compatible format)
2. An import in `_execute_tool()`
3. An entry in `tool_map`
4. The `_execute_tool` returns `(text, structured)` tuple

## System Prompt: Identity

The agent MUST identify as the SaaS's own brand, never mention underlying AI providers.

```python
SYSTEM_PROMPT = """你是 CDP 小助手，一个专为客户数据平台打造的 AI 运营助手。

## 身份
- 你的名字是"CDP 小助手"
- 你是由 CDP 平台提供的智能运营工具，不是任何第三方 AI 公司（如 OpenAI、Anthropic）的产品
- 永远不要在你的回复中提及 Claude、GPT、OpenAI、Anthropic 或任何其他 AI 公司的名字
"""
```

## RAG: TF-IDF for China Network

In China, HuggingFace downloads are ~20KB/s. Avoid embedding model downloads.
Use TF-IDF instead for small knowledge bases (<1000 docs).

```python
class TfidfSearcher:
    def _tokenize(self, text):
        chinese = re.findall(r'[\u4e00-\u9fff]{2,4}', text)
        english = re.findall(r'[a-zA-Z]{2,}', text.lower())
        return chinese + english
```

## API Key Format

Default: `cdp_<32 hex chars>` (36 chars total).
The user prefers the long format over short custom keys.
Support custom keys via `custom_key` parameter for flexibility.

## Pitfalls

- **frp proxy name conflicts**: When frpc is killed and restarted quickly, old proxy names remain registered on frps for ~90 seconds (heartbeat timeout). Solution: wait 90s, or use unique proxy names, or restart frps on VPS.
- **frp LaunchAgent auto-restart**: Hermes creates `com.hermes.frpc.plist` with KeepAlive=true. To change frpc config: `launchctl unload` → edit config → wait for frps timeout → `launchctl load`.
- **Alibaba Cloud security group**: Only specific ports (80, 8080, 7000) are open by default. New ports need to be added in the ECS security group inbound rules.
- **Demo HTML loading state**: Use `raw=true` in `appendMessage()` for loading spinners to avoid `formatMarkdown()` escaping HTML tags.
- **Structured card append**: Check `if (html)` before `appendChild()` to avoid null reference when `renderStructured()` returns empty string for unknown types.
