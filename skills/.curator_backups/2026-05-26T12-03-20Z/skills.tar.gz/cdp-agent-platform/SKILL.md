---
name: cdp-agent-platform
description: "Build AI agent platforms for CDP/SaaS — FastAPI + LLM tool-calling + structured output + multi-model + RAG + RBAC. Covers the full stack pattern emerged from the CDP Agent build session."
version: 1.0.0
category: autonomous-ai-agents
metadata:
  hermes:
    tags: [cdp, agent, fastapi, llm, saas, tool-calling, rag, rbac]
---

# CDP Agent Platform

Full-stack pattern for building AI agent platforms that sell to SaaS companies.
Covers: FastAPI + LLM function-calling + 40+ CDP tools + structured output +
multi-model + RAG + RBAC + scheduling + deployment.

## Architecture

```
┌────────────────────────────────────┐
│  Web UI (demo.html)  │ Admin Panel│
├────────────────────────────────────┤
│  FastAPI (main.py) — 46 endpoints  │
│  ├─ /chat /chat/structured /stream │
│  ├─ /admin/* /models /tasks        │
│  └─ /webhooks /ingest /reports     │
├────────────────────────────────────┤
│  Agent Engine (agent.py)           │
│  ├─ ReAct loop + function calling  │
│  ├─ 42 tool definitions            │
│  └─ Trace + structured output      │
├────────────────────────────────────┤
│  Infrastructure                    │
│  ├─ auth.py — RBAC (admin/analyst/viewer)│
│  ├─ database.py — MySQL/SQLite/mock      │
│  ├─ models.py — multi-model + cost       │
│  ├─ scheduler.py — async task scheduler  │
│  └─ rag.py — TF-IDF knowledge base       │
└────────────────────────────────────┘
```

## Key Patterns

### 1. ReAct Loop with Function Calling

```python
async def run_agent(user_message, history):
    messages = [system_prompt, *history, user_message]
    for _ in range(MAX_TOOL_CALLS):
        response = client.post(..., tools=TOOL_DEFINITIONS)
        msg = response.choices[0].message
        if msg.tool_calls:
            for tc in msg.tool_calls:
                result = execute_tool(tc.name, tc.args)
                messages.append(tool_result)
            continue
        return msg.content
```

### 2. Structured Output Pattern

Tools return `ToolResult(text_for_llm, structured_data)` — the LLM sees
human-readable text, but the API also returns machine-readable JSON
(SQL, workflow JSON, metrics). Added via `/chat/structured` endpoint.

### 3. FastAPI RBAC Pattern

```python
# auth.py: validate_api_key returns {"tenant": T, "role": "admin"}
def require_role(action):
    async def checker(auth=Depends(get_auth)):
        if not check_permission(auth["role"], action):
            raise HTTPException(403, f"权限不足")
        return auth
    return checker

# Usage:
@app.post("/admin/keys")
async def create_key(auth=Depends(require_role("manage"))):
    ...
```

**Pitfall**: FastAPI `str` params default to query string, not JSON body.
When accepting `role: str="admin"` in POST, it won't read from JSON body.
Use `request: Request` + `body = await request.json()` for POST params.

### 4. Multi-Model with Cost Tracking

```python
class ModelManager:
    def get_current(self) -> ModelProvider
    def set_model(self, name) -> bool
    def record_usage(self, model, tokens_in, tokens_out)
    def get_fallback_chain(self) -> list[str]
    def try_fallback(self) -> Optional[str]
```

Cache-busting: delete `model_config.json` when changing defaults,
otherwise stale config persists across restarts.

### 5. TF-IDF RAG (China-friendly)

When embedding models are too large to download (~80MB at 20KB/s),
use TF-IDF for small document sets (<1000 docs). No model download,
instant startup, works well for Chinese + English mixed text.

```python
class TfidfSearcher:
    def index(self, documents)     # tokenize + IDF
    def search(self, query, top_k) # cosine-like scoring
```

### 6. Data Source Abstraction

```python
class DataSource(ABC):
    def query_users(filters) -> list[dict]
    def get_user(user_id) -> dict

class MockSource(DataSource): ...  # JSON files
class SQLSource(DataSource): ...  # MySQL/SQLite
```

Tools use `get_source()` — switch between mock and real DB transparently.

### 7. API Key Bootstrap Problem

When `POST /admin/keys` requires authentication, there's no key to
create the first admin key. Solution: keep `/admin/keys` unauthenticated
for initial bootstrap, or create a key directly in the JSON file.

### 8. Chinese IME Handling

```javascript
function onKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    send();  // Only send when IME is not composing
  }
}
```

### 9. Light/Dark Theme Toggle

Store theme colors in CSS variables, toggle by swapping root variable
values. Keep both theme palettes in JS, apply via `setProperty`.

## System Prompt Identity

Always identify as the platform's own assistant ("CDP小助手"), never
mention Claude, GPT, OpenAI, Anthropic, or any other AI company.
Explicit identity instruction in system prompt top section.

## Deployment

- **frp tunnel**: LaunchAgent (`com.hermes.frpc.plist`) auto-restarts frpc
- **Agent service**: LaunchAgent (`com.cdp.agent.plist`) with KeepAlive
- **Pitfall**: killing frpc without unloading the LaunchAgent causes it to
  auto-restart, creating "proxy already exists" conflicts. Unload first:
  `launchctl unload ~/Library/LaunchAgents/com.hermes.frpc.plist`

## File Structure

```
agent-for-saas/
├── app/
│   ├── main.py          # FastAPI (46 endpoints)
│   ├── agent.py         # ReAct engine (42 tools)
│   ├── auth.py          # RBAC + multi-tenant
│   ├── database.py      # Data source abstraction
│   ├── models.py        # Multi-model + cost
│   ├── scheduler.py     # Async task scheduler
│   ├── rag.py           # TF-IDF knowledge base
│   ├── guard.py         # Content safety + prompt versions
│   ├── store.py         # SQLite sessions
│   ├── webhook.py       # Webhook callbacks
│   └── tools/           # 42 CDP-specific tools
├── demo.html            # Web chat UI (DeepSeek-style)
├── admin.html           # Admin panel (Copilot Studio-style)
├── static/chat-widget.js # Embeddable SDK
└── data/                # Mock data + knowledge base
```

## Pitfalls Summary

- **FastAPI POST params**: Use `request.json()` not function params for POST
- **Model config caching**: Delete `model_config.json` after changing defaults
- **frp LaunchAgent**: Unload before killing, or it auto-restarts
- **API key bootstrap**: Keep initial key creation unauthenticated
- **Chinese IME**: Check `e.isComposing` before sending on Enter
- **ChromaDB download**: Use TF-IDF when model downloads are slow
- **System prompt identity**: Never leak underlying model brand
