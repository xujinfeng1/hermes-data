---
name: agent-for-saas
description: "Patterns for building embeddable AI agents for SaaS products — ReAct loop, structured output (ToolResult), TF-IDF RAG, multi-tool architecture, and demo UI patterns."
version: 1.0.0
author: Agent
metadata:
  hermes:
    tags: [agent, saas, cdp, architecture, tool-design]
---

# Agent for SaaS — 构建可嵌入 SaaS 的 AI Agent

本 skill 记录了构建一个可嵌入 CDP/电商 SaaS 的 AI Agent 的核心模式。

## 架构模式

### ToolResult — 双通道输出

Agent 的工具不只返回文本给 LLM 看，还返回结构化数据给 API 消费：

```python
@dataclass
class ToolResult:
    text: str              # LLM 看的 NL 文本
    structured: dict|None  # SaaS 消费的机器数据

def segment_users(...) -> ToolResult:
    return ToolResult(
        text="找到 5 人...",          # 给 LLM
        structured={                  # 给 API
            "type": "segment",
            "sql_where": "gender='女' AND total_spent>=10000",
            "user_ids": [...]
        }
    )
```

Agent 用 `.text` 继续对话，API 端点提取 `.structured` 直接输出 SQL/JSON。

### ReAct 循环 + DeepSeek Function Calling

```
用户消息 → [System Prompt + History + Tools] → DeepSeek API
  → 有 tool_calls? → 执行工具 → 结果追加到 messages → 继续循环
  → 无 tool_calls? → 最终回复
  → 超过 MAX_TOOL_CALLS? → 超时处理
```

DeepSeek 使用 OpenAI 兼容格式。tools 定义用标准 JSON Schema。

### TF-IDF RAG（轻量知识检索）

避免下载大型 embedding 模型（国内网络慢）：
- 使用 sklearn-free 的纯 Python TF-IDF 实现
- 中文分词用 2-4 字滑动窗口 + 正则
- 适合 <1000 篇文档的小型知识库
- 零模型下载，秒启动

### 多工具注册

工具分为独立文件，统一注册：

```
app/tools/
  cdp_audience.py   # 圈人
  cdp_tag.py        # 标签 + 画布
  cdp_analytics.py  # 漏斗/留存/活动
  cdp_predict.py    # 流失/LTV/NBA
  cdp_auto.py       # 巡检/端到端
  cdp_report.py     # 日报/周报
  cdp_rag.py        # 知识检索
  cdp_advanced.py   # 归因/队列
```

每个工具文件包含 1-4 个函数，返回 ToolResult。

## Demo UI 模式

### IME 输入法修复

中文输入法组合文字时按回车不应发送消息：

```javascript
function onKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    send();
  }
}
```

`e.isComposing` 在 IME 激活时为 true。

### 交互式操作确认

在 Agent 回复下方渲染操作按钮：

```javascript
// 根据回复内容智能判断需要哪些操作
function renderActions(msg) {
  if (content.includes('圈')) return '✅ 确认人群 | ✏️ 修改 | 🎯 创建画布';
  if (content.includes('画布')) return '🚀 确认执行 | ✏️ 修改 | 取消';
  // ...
}
```

确认操作使用弹窗（overlay + dialog），执行后替换按钮为状态文本。

### 修改 Agent 输出

就地编辑模式：保留原始内容，修改后存储到会话历史，支持还原。

## 部署模式

### LaunchAgent 持久化（macOS）

```xml
<!-- ~/Library/LaunchAgents/com.cdp.agent.plist -->
<key>KeepAlive</key><true/>
<key>RunAtLoad</key><true/>
```

配合 frp 实现外网访问。注意 frp 的 LaunchAgent 自动重启问题（见 frp-setup skill）。

## RBAC 权限模式

### FastAPI POST body 陷阱

FastAPI 的 `role: str = "admin"` 参数默认从 query string 读取，POST JSON body 里的 `role` 会被忽略，始终使用默认值：

```python
# ❌ 错误：role 从 query string 读，body 里的 role 被忽略
async def create_key(role: str = "admin"): ...

# ✅ 正确：从 request body 读取
async def create_key(request: Request):
    body = await request.json()
    role = body.get("role", "admin")
```

### 权限中间件

```python
def require_role(action: str):
    async def checker(auth=Depends(get_auth)):
        if not check_permission(auth["role"], action):
            raise HTTPException(403, f"权限不足")
        return auth
    return checker
```

权限矩阵：admin(全部) / analyst(chat+analyze+export) / viewer(read)。

## 多模型切换

`app/models.py` 管理模型配置和成本追踪。Agent 动态读取当前模型：

```python
current = model_mgr.get_current()
resp = httpx.post(f"{current.base_url}/chat/completions",
    headers={"Authorization": f"Bearer {model_mgr.get_api_key(current.name)}"},
    json={"model": current.model, ...})
```

## 工程控制论工作流（必须遵守）

系统观→反馈控制→稳定性第一→最优化→可靠性→信息论→鲁棒性→系统辨识→自适应→分级递阶→人机协同。

### 反例

- 视频卡住 → 直接改代码，没先查 ComfyUI 是否在线 ❌
- 连续加 5 功能 → 全部做完才测试，基础功能早已坏 ❌

### 正例

```
问题 → 1.查日志/进程 → 2.定位根因 → 3.最小修复 → 4.验证 → 5.回归基本功能
```

## Demo UI 高级模式

- 桑基图 SVG：journey_map structured 数据用纯 SVG 渲染节点+连线
- 编辑还原：修改后保留 originalContent，支持一键还原
- IME 修复：`e.isComposing` 判断输入法状态

## 项目结构模板

```
agent-for-saas/
├── app/
│   ├── agent.py       # ReAct 循环 + 工具定义 + System Prompt
│   ├── main.py        # FastAPI（鉴权/配额/会话/结构化端点）
│   ├── schemas.py     # Pydantic 模型
│   ├── config.py      # 环境变量配置
│   ├── errors.py      # 错误类型 + LLM 重试
│   ├── auth.py        # API Key + 多租户 + 配额
│   ├── store.py       # SQLite 持久化会话
│   ├── rag.py         # 检索引擎
│   ├── structured.py  # ToolResult + 结构化输出模型
│   ├── webhook.py     # Webhook 管理
│   └── tools/         # 工具实现（按领域分文件）
├── data/              # Mock 数据 + 知识库 + 报表 + 会话 DB
├── demo.html          # 单文件 Demo UI
└── requirements.txt
```
