---
name: agent-service
description: Build LLM agents as FastAPI services for SaaS embedding — ReAct loop, function calling, tool system, mock data, multi-turn testing.
version: 1.0.0
platforms: [linux, macos]
---

# Agent Service

Build LLM-powered agents exposed as REST APIs, designed for embedding in SaaS products
or selling to SaaS companies as an integrated AI capability.

## When to Use

- Building an AI agent that needs to be called by external systems via REST API
- Embedding LLM capabilities into an existing SaaS product (e-commerce, CRM, etc.)
- Creating a domain-specific agent (customer service, order lookup, FAQ) for distribution
- Productizing agent capabilities as a service to sell to other companies

## Architecture Pattern

Three-layer separation with clear boundaries:

```
Tools Layer (domain logic)
    ↓ called by
Agent Core (ReAct loop + LLM function calling)
    ↓ called by
API Layer (FastAPI endpoints)
```

This separation means: swap mock data for real DB in tools layer without touching
agent logic; swap LLM provider in agent core without touching API or tools.

## Project Structure

```
project/
├── app/
│   ├── agent.py          # ReAct loop: send msg → LLM → tool_call → result → reply
│   ├── main.py           # FastAPI: /chat, /chat/stream, /health
│   ├── config.py          # Env vars (API key, base URL, model name)
│   ├── schemas.py         # Pydantic request/response models
│   └── tools/
│       ├── __init__.py    # Re-exports all tool functions
│       ├── product.py     # Domain tool 1
│       ├── order.py       # Domain tool 2
│       └── faq.py         # Domain tool 3
├── data/
│   ├── products.json      # Mock data — Phase 1; replace with DB in Phase 2
│   ├── orders.json
│   └── faq.json
├── .env                   # API keys (never commit)
├── .env.example           # Template for other developers
├── requirements.txt
└── venv/
```

## Key Design Decisions

### 1. ReAct Loop (agent.py)

```python
async def run_agent(user_message, history):
    messages = [system_prompt, *history, user_message]

    for turn in range(MAX_TOOL_CALLS):  # default 5
        response = await llm.chat(messages, tools=TOOL_DEFINITIONS)
        if response.tool_calls:
            for tc in response.tool_calls:
                result = execute_tool(tc.name, tc.args)
                messages.append(tool_result_message(result))
            continue  # let LLM see tool results
        return response.content  # final answer
```

Key: loop continues until LLM produces text without tool calls, or max turns hit.

### 2. Tool Definitions

Define tools in OpenAI-compatible format as module-level constant:

```python
TOOL_DEFINITIONS = [{
    "type": "function",
    "function": {
        "name": "search_products",
        "description": "搜索商品...",
        "parameters": { ... }
    }
}]
```

Each tool function is a plain Python function in `app/tools/`. The tool dispatch
map resolves by name at runtime. This keeps tools testable independently of the agent.

### 3. System Prompt

Must be domain-specific and enforce data fidelity:

- Answer in the user's language (Chinese for Chinese users)
- Never fabricate data — always use tool results
- Route queries to appropriate tools (product → search_products, order → query_order, policy → search_faq)
- Escalate to human for out-of-scope requests

### 4. Session Management (Phase 1)

In-memory dict: `{session_id: [message, message, ...]}`.
Limit history to last 20 messages.
Replace with Redis/DB in Phase 3 when multi-instance needed.

### 5. API Design

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Liveness check |
| `/chat` | POST | Standard request/response with session |
| `/chat/stream` | POST | SSE streaming for real-time UI |
| `/sessions/{id}` | DELETE | Clear session history |

Request body: `{"message": "...", "session_id": "optional"}`

## Verification

After building, test with curl:

```bash
# Health
curl http://localhost:8800/health

# Product search
curl -X POST http://localhost:8800/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "有什么蓝牙耳机？"}'

# Order query
curl -X POST http://localhost:8800/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "查订单 ORD20240503003"}'

# Multi-turn with session
SESSION=$(curl -s -X POST ... | jq -r '.session_id')
curl -X POST ... -d "{\"message\": \"...\", \"session_id\": \"$SESSION\"}"
```

Verify: tool_calls_made in response confirms correct tool routing.
Verify: multi-turn remembers previous context without re-calling tools.

## Pitfalls

- **Tool definitions mismatch**: If TOOL_DEFINITIONS parameter names don't match
  the Python function signatures, LLM will call with wrong args. Keep them aligned.
- **History bloat**: Without length limiting, tool result messages accumulate.
  Cap at 20 messages in Phase 1.
- **DeepSeek streaming**: tool_calls arrive fragmented across SSE chunks. Must
  accumulate arguments across deltas, not assume they arrive in one piece.
- **API key masking**: Terminal output may mask keys with `***`. Use `read_file`
  or direct Python `open()` to read .env files when extracting keys for new projects.
  See `references/deepseek-setup.md` for Hermes-specific key extraction.

## Phase Roadmap

| Phase | Scope | Key Deliverable |
|-------|-------|-----------------|
| 1 | Core engine | Agent with mock data, FastAPI, curl-testable |
| 2 | API hardening | Streaming, JS SDK, Chat Widget, API key auth |
| 3 | Multi-tenant | Tenant isolation, billing, admin panel |
| 4 | Production | Docker, monitoring, SLA, docs |
