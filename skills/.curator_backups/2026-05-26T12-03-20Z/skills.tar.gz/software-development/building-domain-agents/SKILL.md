---
name: building-domain-agents
description: Build domain-specific AI agents with ReAct loop, function calling, FastAPI wrapper, and mock data. For use when the user wants to build an AI agent product for a specific business domain (CDP, e-commerce, CRM, etc.). Covers architecture, tool design, testing, and competitive analysis.
version: 1.0.0
platforms: [linux, macos]
---

# Building Domain-Specific AI Agents

Use this skill when the user wants to build an AI agent targeting a specific business domain — especially when the agent will be embedded into or sold alongside an existing SaaS product.

## Architecture Pattern

```
agent-project/
├── app/
│   ├── agent.py          # Core ReAct loop + tool definitions + system prompt
│   ├── main.py           # FastAPI wrapper (/chat, /chat/stream, /health)
│   ├── config.py         # Env-based config (API keys, model, limits)
│   ├── schemas.py        # Pydantic request/response models
│   └── tools/
│       ├── domain_a.py   # One file per tool category
│       ├── domain_b.py
│       └── __init__.py   # Re-exports all tool functions
├── data/
│   ├── domain_entities.json   # Rich mock data for the domain
│   └── domain_events.json     # Behavioral/timeline data
├── .env                 # API keys (not committed)
├── requirements.txt
└── venv/
```

## Core Principles

### 1. ReAct Loop with Function Calling

The agent loop:
1. Send `[system_prompt, history..., user_message]` + tool definitions to LLM
2. If LLM returns `tool_calls` → execute tools → append results → loop (up to MAX_TOOL_CALLS)
3. If LLM returns plain `content` → final answer

Use the OpenAI-compatible function calling format. DeepSeek, Qwen, and most domestic models support it.

### 2. Tool Design

Each tool is a plain Python function that:
- Takes typed parameters matching the LLM's tool definition schema
- Returns a formatted string (the LLM interprets this for the final reply)
- Loads data from JSON files (Phase 1) → replace with real DB later (Phase 3)

Tool files are grouped by domain concept: audience tools, profile tools, campaign tools, etc.

### 3. System Prompt

The system prompt must:
- Define the agent's role and domain
- Map user's natural language phrases to tool parameters ("高消费" → min_total_spent=10000)
- Describe the workflow (when to call which tool, in what order)
- Set tone and language (简洁专业的中文)

### 4. Mock Data

Mock data must be rich enough to demonstrate real value:
- For CDP: 10+ user profiles with diverse stats, 30+ behavioral events, tag definitions, predefined segments
- Each entity has enough fields for realistic multi-condition filtering
- Data distribution should include edge cases (VIP with 150+ orders, new user with 0 orders, dormant user with 30+ days inactive)

### 5. Testing

Test the complete flow end-to-end with actual API calls:
- 圈人 (audience segmentation with multiple conditions)
- 用户画像 (360° profile + behavior timeline)
- 多轮对话 (context memory across turns)
- 营销动作 (canvas generation based on audience)

Use `execute_code` with `subprocess.run(["curl", ...])` to test the running server.

## Workflow When Building

1. **Understand the domain**: Research the SaaS category, core features, and user personas
2. **Stop any running services first**: Before making major changes or comparisons, kill the running server. The user prefers a clean state before pivoting.
3. **Competitive analysis before building more**: When the user says "对比一下" or mentions competitors, pause development and do the research. The user values knowing the competitive landscape before committing to features.
4. **Design mock data**: Create realistic domain entities (users, events, tags, segments, etc.) — rich enough to demonstrate real value, diverse enough to cover edge cases
5. **Build tools**: One file per tool category, plain functions, typed parameters. Group by domain concept.
6. **Write system prompt**: Role, workflow, parameter mapping (NL phrases → tool parameters), tone — must instruct agent to use tools, not hallucinate
7. **Wrap in FastAPI**: `/chat` (sync), `/chat/stream` (SSE), session management via in-memory dict. CORS open in Phase 1, tighten in Phase 3.
8. **Test end-to-end**: Use `execute_code` with Python `subprocess` for multi-turn testing (shell variable assignment breaks session IDs). Test: 圈人 → 画像 → 多轮记忆 → 营销动作.

## Pitfalls

- **Tool hallucination**: LLM may answer without calling tools. System prompt must instruct: "一切以工具返回的数据为准，不要编造"
- **Session variable leakage in shell**: When testing multi-turn with bash, session_id often breaks in variable assignment. Use `execute_code` with Python `subprocess` instead.
- **Credential access**: API keys managed by Hermes are masked in terminal output. Read from `~/.hermes/.env` directly in `execute_code` and write to project `.env`.
- **Agent must adapt to domain pivot**: If user changes direction (e.g., e-commerce → CDP), rewrite mock data, tools, and system prompt — don't try to bolt on.

## References

- `references/cdp-domain-notes.md` — CDP-specific knowledge: core features, competitive landscape, agent opportunity map
