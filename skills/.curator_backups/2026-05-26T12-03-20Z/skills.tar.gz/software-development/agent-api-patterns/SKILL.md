---
name: agent-api-patterns
description: Production patterns for building AI Agent APIs — structured output, RBAC, FastAPI integration, demo UI with interactive confirm/edit.
version: 1.0.0
metadata:
  hermes:
    tags: [agent, api, fastapi, rbac, structured-output, demo]
---

# Agent API Patterns

Reusable architecture patterns for building production AI agent APIs with FastAPI.

## Architecture

```
app/
├── agent.py          # ReAct loop + tool definitions + system prompt
├── main.py           # FastAPI routes (chat, structured, admin, export)
├── auth.py           # API Key auth + multi-tenant + RBAC + quota
├── store.py          # Persistent session store (SQLite)
├── structured.py     # ToolResult + Segment/Canvas/Funnel output models
├── rag.py            # Knowledge base search (TF-IDF or embeddings)
├── errors.py         # Error types + LLM retry with exponential backoff
├── schemas.py        # Pydantic request/response models
├── config.py         # Env-based config (API keys, model, etc.)
└── tools/
    ├── __init__.py   # Re-export all tool functions
    ├── cdp_*.py      # Domain-specific tools
    └── ...
```

## Structured Output Pattern (ToolResult)

Every tool returns `ToolResult(text, structured)` instead of raw strings. 
The `text` is fed to the LLM for reasoning. The `structured` dict is extracted by the API layer and returned alongside the NL response.

```python
# tool returns
return ToolResult(
    text="圈选到 5 个用户\n  U001 张三 ...",
    structured=SegmentOutput(
        conditions=[...], sql_where="gender='女' AND total_spent>=10000",
        user_count=5, users=[...]
    ).__dict__
)

# agent extracts .text for LLM, API extracts .structured for response
text, struct = _execute_tool(name, args)
messages.append({"role": "tool", "content": text})  # LLM sees text only
structured_data.append(struct)  # API response includes structured
```

## RBAC Pattern (FastAPI + Agent)

Three roles: `admin` (full), `analyst` (chat+analyze), `viewer` (read).

```python
# auth.py
def check_permission(role: str, action: str) -> bool:
    permissions = {
        "admin": {"chat", "analyze", "manage", "export", "read"},
        "analyst": {"chat", "analyze", "export", "read"},
        "viewer": {"read"},
    }
    return action in permissions.get(role, set())

# main.py — inline RBAC in chat core (most reliable)
async def _chat_core(req, auth):
    if not check_permission(auth["role"], "chat"):
        raise HTTPException(403, f"权限不足：角色 '{auth['role']}' 不能使用对话功能")
```

### Pitfall: FastAPI POST body vs query params
FastAPI function parameter `role: str="admin"` reads from QUERY STRING, not JSON body.
For POST endpoints accepting JSON, use `request: Request` + `body = await request.json()`.
Otherwise parameters silently default to their defaults.

## Demo UI Pattern

Single-file HTML with:
- Sidebar: conversation list + API key + endpoint selector
- Chat: markdown tables, structured data cards, interactive action buttons
- Actions: confirm/cancel/edit/copy/create-canvas buttons per message
- Edit mode: inline textarea to modify agent output, save back to conversation
- IME-safe: `!e.isComposing` on Enter key to avoid sending during Chinese input

## Agent Identity

Always set explicit identity in system prompt to prevent LLM from self-identifying as Claude/GPT:

```
你是 CDP 小助手，一个专为客户数据平台打造的 AI 运营助手。
永远不要在你的回复中提及 Claude、GPT、OpenAI、Anthropic 或任何其他 AI 公司的名字。
如果用户问你是谁，回答："我是 CDP 小助手，你的智能客户数据运营伙伴"
```

## Deployment (macOS LaunchAgent)

```xml
<!-- ~/Library/LaunchAgents/com.cdp.agent.plist -->
<key>ProgramArguments</key>
<array>
    <string>/path/to/venv/bin/python</string>
    <string>-m</string><string>uvicorn</string>
    <string>app.main:app</string>
    <string>--host</string><string>0.0.0.0</string>
    <string>--port</string><string>8800</string>
</array>
<key>WorkingDirectory</key><string>/path/to/project</string>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><true/>
```

frp tunnel pattern: map local port to VPS public port via frpc LaunchAgent.
