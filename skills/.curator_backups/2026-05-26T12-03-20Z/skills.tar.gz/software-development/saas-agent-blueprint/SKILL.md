---
name: saas-agent-blueprint
description: Architecture patterns for building domain-specific AI agents that embed into SaaS products. Covers ReAct loop with function calling, FastAPI service wrapper, domain tool design, and system prompt engineering for operational agents.
version: 1.0.0
---

# SaaS Agent Blueprint

Use this skill when building a domain-specific AI agent meant to be embedded in a SaaS product — customer service, CDP operations, marketing automation, analytics copilot, or similar operational agents.

## Architecture Pattern

```
app/
├── agent.py          # ReAct loop + tool definitions + system prompt
├── main.py           # FastAPI (/chat, /chat/stream, /health)
├── config.py          # Env-based config (API keys, model, limits)
├── schemas.py         # Pydantic request/response models
└── tools/             # Domain-specific tool implementations
    ├── tool_a.py      # Each tool = a standalone module
    ├── tool_b.py
    └── __init__.py    # Re-export all tool functions
```

## ReAct Loop (DeepSeek / OpenAI-compatible)

```python
async def run_agent(user_message, history=None):
    messages = [system_prompt, *history, user_message]
    for _ in range(MAX_TOOL_CALLS):
        response = await client.post(api_url, json={
            "model": MODEL, "messages": messages,
            "tools": TOOL_DEFINITIONS, "temperature": 0.3
        })
        msg = response["choices"][0]["message"]
        if msg.get("tool_calls"):
            messages.append(msg)  # assistant message with tool_calls
            for tc in msg["tool_calls"]:
                result = execute_tool(tc["function"]["name"], json.loads(tc["function"]["arguments"]))
                messages.append({"role": "tool", "tool_call_id": tc["id"], "content": result})
            continue  # loop back so LLM sees tool results
        return msg["content"]  # final answer
```

Key rules:
- Temperature 0.3 for operational agents (need consistency, not creativity)
- MAX_TOOL_CALLS = 5 is usually enough; higher risks loops
- Always append tool results as `role: "tool"` with matching `tool_call_id`
- Stream version: same loop, but collect chunks from SSE, reassemble tool_calls buffer

## Tool Design Principles

1. **One function = one tool definition.** Each tool function gets a corresponding entry in TOOL_DEFINITIONS with JSON Schema parameters. Don't overload — if a function does two different things, split it.

2. **Parameters are the NL bridge.** The LLM reads parameter descriptions to decide what to pass. Write them in the user's language. "描述" not "description" if the user speaks Chinese.

3. **Return strings, not objects.** Tool results go back into the LLM context as text. Format them for LLM readability: use tables, emoji markers, clear section headers.

4. **Mock data from JSON files.** Phase 1 use `data/*.json`. Phase 2 swap to real DB without changing tool signatures.

## System Prompt Engineering

For operational agents, the system prompt must include:

- **Role definition**: "你是 X 系统的智能运营助手"
- **Capability mapping**: what NL phrases map to which tool + which parameters. E.g., "近30天买过3次以上" → `min_orders_30d=3`
- **Workflow rules**: when to call multiple tools in sequence, when to ask clarifying questions
- **Anti-hallucination**: "一切以工具返回数据为准，不要编造"
- **Condition mapping table**: common NL terms → parameter values (e.g., "高消费" → min_total_spent >= 10000)

## FastAPI Wrapper

```python
# main.py — standard pattern
@app.post("/chat")
async def chat(req: ChatRequest):
    session_id, history = _get_or_create_session(req.session_id)
    result = await run_agent(req.message, history)
    history.append({"role": "user", "content": req.message})
    history.append({"role": "assistant", "content": result["reply"]})
    if len(history) > 20:  # trim to avoid context overflow
        sessions[session_id] = history[-20:]
    return ChatResponse(reply=result["reply"], session_id=session_id, tool_calls_made=result["tool_calls_made"])
```

Session storage: in-memory dict for Phase 1, Redis/DB for production.

## Pitfalls

- **run_agent_stream must exist in agent.py** if main.py imports it. When rewriting agent.py, don't forget to include the stream function or main.py will crash on import.
- **Tool results are text, not code.** The LLM reads them. Format for LLM comprehension, not human JSON.
- **Session trim is critical.** Without history length limits, context grows until it exceeds the model's max tokens. 20 turns is a safe default for chat models.
- **Streaming + tool calls don't mix in a single yield.** When streaming, accumulate the full response first, check for tool_calls, then either yield text chunks or execute tools. Don't yield text AND try to call tools in the same iteration.

## CDP-Specific Patterns

For CDP agents specifically, see `references/cdp-tool-patterns.md` — covers audience segmentation (NL→conditions→filter), marketing canvas generation (template-based with branching), and analytics (funnel/retention/campaign computed from event streams).
