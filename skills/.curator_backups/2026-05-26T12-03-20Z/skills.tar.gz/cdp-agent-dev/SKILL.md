---
name: cdp-agent-dev
description: "Build AI agents for Customer Data Platforms — ReAct pattern, CDP tools (audience/canvas/analytics/prediction/RAG), FastAPI API patterns, RBAC, and deployment."
version: 1.0.0
category: autonomous-ai-agents
platforms: [linux, macos]
metadata:
  hermes:
    tags: [cdp, agent, fastapi, deepseek, rag, rbac, scheduler]
---

# CDP Agent 开发

Build an AI agent product for Customer Data Platforms. The agent helps SaaS
operators manage audiences, marketing canvases, analytics, predictions, and
automation through natural language.

## Architecture

```
User (NL) → Agent (ReAct loop) → Tools (CDP functions) → Mock/Real Data
                ↑                        ↓
           DeepSeek API            Structured Output (SQL/JSON/Workflow)
```

Core pattern: DeepSeek Function Calling with ReAct loop. Agent receives user
message, sends to LLM with tool definitions, LLM decides which tool to call,
agent executes tool and feeds result back, LLM produces final answer.

## Project Structure

```
agent-for-saas/
├── app/
│   ├── agent.py          # ReAct loop + TOOL_DEFINITIONS + SYSTEM_PROMPT
│   ├── main.py           # FastAPI app (endpoints, auth, middleware)
│   ├── auth.py           # API Key auth + RBAC + quota
│   ├── store.py          # SQLite session persistence
│   ├── rag.py            # TF-IDF knowledge base (no model download)
│   ├── scheduler.py      # asyncio task scheduler
│   ├── structured.py     # ToolResult + SegmentOutput + SQL builder
│   ├── errors.py         # Retry logic + error types
│   ├── webhook.py        # Webhook registration + firing
│   └── tools/
│       ├── cdp_audience.py   # segment_users, list_segments
│       ├── cdp_profile.py    # get_user_profile, get_user_events
│       ├── cdp_tag.py        # create_marketing_canvas (7 goal types)
│       ├── cdp_analytics.py  # funnel, retention, campaign
│       ├── cdp_predict.py    # churn, LTV, NBA, anomaly
│       ├── cdp_auto.py       # health check, auto campaign, optimize
│       ├── cdp_report.py     # daily/weekly reports
│       ├── cdp_advanced.py   # attribution, cohort
│       ├── cdp_journey.py    # journey map (Sankey data)
│       ├── cdp_rag.py        # search_knowledge_base
│       ├── cdp_schedule.py   # schedule_task, list/remove/run
│       ├── cdp_export.py     # chart, export, share link
│       └── ...
├── data/                 # JSON mock data + SQLite + reports
├── static/               # chat-widget.js (embeddable SDK)
├── demo.html             # DeepSeek-style chat UI
└── venv/
```

## Key Patterns

### 1. ToolResult — Dual Output

Every tool returns a `ToolResult` with two fields:
- `text`: human-readable, fed to the LLM for context
- `structured`: machine-readable dict, surfaced in API response

```python
from app.structured import ToolResult

return ToolResult(
    text="Found 5 users...",
    structured=SegmentOutput(conditions=[...], sql_where="...", users=[...]).__dict__,
)
```

The agent's `_execute_tool` unwraps: `text` goes to the LLM, `structured` goes
to the API response's `structured` field.

### 2. Agent Tool Registration

Three places to update when adding a tool:
1. `app/tools/<file>.py` — implement the function, return `ToolResult`
2. `app/agent.py` — add to `TOOL_DEFINITIONS` list + `_execute_tool` import + `tool_map`
3. `app/tools/__init__.py` — re-export

### 3. Structured Segment Output

Circle-back tool outputs SQL WHERE clauses and JSON filter objects that SaaS
can execute directly:

```python
conditions = [
    {"field": "gender", "op": "eq", "value": "女"},
    {"field": "total_spent", "op": "gte", "value": 10000},
]
sql = build_sql_where(conditions)  # → "gender = '女' AND total_spent >= 10000"
```

Use `/chat/structured` endpoint to get both NL reply + SQL/JSON in one call.

### 4. RBAC Pattern

Three roles (see `references/fastapi-patterns.md` for the POST body trap).

```python
# auth.py — define permissions
permissions = {
    "admin": {"chat", "analyze", "manage", "export", "read"},
    "analyst": {"chat", "analyze", "export", "read"},
    "viewer": {"read"},
}

# main.py — enforce on endpoints
@app.post("/chat")
async def chat(req, auth=Depends(require_role("chat"))):
    ...
```

**Pitfall**: FastAPI reads default parameter values like `role: str="admin"`
from query strings, NOT from JSON POST bodies. When accepting role in POST
requests, use `request = await request.json()` directly:

```python
# WRONG — role always defaults to "admin" from query string
async def create_key(role: str = "admin"):
    ...

# RIGHT — read from JSON body
async def create_key(request: Request):
    body = await request.json()
    role = body.get("role", "admin")
    ...
```

### 5. TF-IDF RAG (No Model Download)

In China, HuggingFace downloads are slow (~20KB/s for 80MB model). Use TF-IDF
keyword matching for small document sets (<1000 docs) instead of embedding models:

```python
class TfidfSearcher:
    def index(self, documents):  # tokenize + compute TF-IDF
    def search(self, query, top_k=3):  # cosine-like scoring
```

Documents stored in `data/knowledge_base.json`. Auto-ingested on startup.

### 6. asyncio Task Scheduler

In-process scheduler using asyncio loop. Parse schedule strings:
- `"daily 9:00"` → every day at 9am
- `"weekly mon 9:00"` → every Monday
- `"interval 30m"` → every 30 minutes

```python
from app.scheduler import scheduler
await scheduler.start()  # in FastAPI lifespan
scheduler.add_task("日报", "report", "daily 9:00")
```

## Deployment

LaunchAgents manage persistence (see `references/deployment.md` for configs).

## Pitfalls

- **System Prompt identity**: Always prefix with "你是 CDP 小助手，不是任何第三方 AI 公司的产品" to prevent the LLM from self-identifying as Claude/GPT. Add explicit instruction: "永远不要提及 Claude、GPT、OpenAI、Anthropic 等 AI 公司名字".

- **Chinese IME Enter key**: In chat UI textareas, check `event.isComposing` to avoid sending message when user presses Enter to confirm IME composition: `if (e.key === 'Enter' && !e.shiftKey && !e.isComposing)`.

- **ChromaDB ONNX download**: DefaultEmbeddingFunction downloads a 79MB ONNX model from AWS S3. In China this takes hours. Use TF-IDF instead (see above).

- **Tool count explosion**: Every new tool requires 3 edits (definition, import, map entry). Batch additions in groups of 4-5 tools per file to reduce integration overhead.

- **Canvas nodes**: Marketing canvas templates use a recursive structure with `yes`/`no`/`a`/`b` sub-arrays for branches and A/B tests. When rendering, use recursive flattening with indent tracking.
